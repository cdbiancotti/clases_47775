from setuptools import setup

setup(
    author='Yo',
    author_email='pepito@mucho.no',
    description='paquete de la clase 15',
    version='0.0.1',
    name='elpaquetito',
    packages=['mi_paquete']
)